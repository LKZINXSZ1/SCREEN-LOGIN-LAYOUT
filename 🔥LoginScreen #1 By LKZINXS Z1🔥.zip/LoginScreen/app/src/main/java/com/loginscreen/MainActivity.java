package com.loginscreen;
 
import android.app.*;
import android.os.*;
import android.widget.*;
import android.graphics.*;
import android.view.*;
import android.widget.RelativeLayout.LayoutParams;
import android.text.*;
import android.content.*;
import android.net.*;

public class MainActivity extends Activity { 

    //LinearConfig
    int LayoutHeight1 = 220;
    int LayoutWidght1 = LayoutHeight1 + 100;
    int LayoutWidght2 = 80;
    
    //TextConfig

    //Strings
	String DARKGRAY = "#FF212121";
	String LIGHTGRAY = "#FF424242";
	String TeamNameStr = "LKZ TEAM";
    String sellerContact = "";
    
    //Widgets
    Button Blogin;
    Button Bsellers;
    LinearLayout Llogin;
    LinearLayout Lsellers;
    TextView contact;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
		//Hide ActionBar
		ActionBar actionBar = getActionBar();
		actionBar.hide();
		
		//Start void [Login]
		Login();
        
        }
		
		
	public void Login(){

		LinearLayout linear = new LinearLayout(this);
		linear.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
		linear.setGravity(Gravity.CENTER);
		linear.setBackgroundColor(Color.TRANSPARENT);
		
		LinearLayout linear2 = new LinearLayout(this);
		linear2.setLayoutParams(new LinearLayout.LayoutParams(LayoutWidght1, LayoutHeight1));
		linear2.setOrientation(LinearLayout.VERTICAL);
		linear2.setPadding(10,10,10,10);
		android.graphics.drawable.GradientDrawable ICEHBCI = new android.graphics.drawable.GradientDrawable();
		ICEHBCI.setColor(Color.parseColor(DARKGRAY));
		ICEHBCI.setCornerRadius(5);
		linear2.setBackground(ICEHBCI);
		if(Build.VERSION.SDK_INT >= 21) { linear2.setElevation(13f); }
		
		LinearLayout linear3 = new LinearLayout(this);
		linear3.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
		linear3.setPadding(0,0,0,5);
		linear3.setGravity(Gravity.CENTER);
		
		TextView TeamName = new TextView(this);
		TeamName.setLayoutParams(new LinearLayout.LayoutParams(-2,-2));
		TeamName.setText(TeamNameStr);
		TeamName.setShadowLayer(3,1,1, Color.parseColor(LIGHTGRAY));
		TeamName.setTextColor(Color.parseColor(LIGHTGRAY));
		TeamName.setTypeface(Typeface.DEFAULT_BOLD);
		
		LinearLayout linear4 = new LinearLayout(this);
		linear4.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
		linear4.setOrientation(LinearLayout.HORIZONTAL);
		
		LinearLayout linear5 = new LinearLayout(this);
		linear5.setLayoutParams(new LinearLayout.LayoutParams(LayoutWidght2, -1));
		linear5.setPadding(0, 5, 0, 5);
        linear5.setOrientation(LinearLayout.VERTICAL);
		android.graphics.drawable.GradientDrawable ECECJEF = new android.graphics.drawable.GradientDrawable();
		ECECJEF.setColor(Color.parseColor(LIGHTGRAY));
		ECECJEF.setCornerRadius(5);
		linear5.setBackground(ECECJEF);
		if(Build.VERSION.SDK_INT >= 21) { linear4.setElevation(9f); }
		
		Blogin = new Button(this);
		Blogin.setLayoutParams(new LinearLayout.LayoutParams(-1, 20));
		Blogin.setPadding(0,0,0,0);
		Blogin.setAlpha(0.6f);
		Blogin.setText("Login");
        Blogin.setAllCaps(false);
		Blogin.setTextSize(9.0f);
		Blogin.setTextColor(Color.parseColor(DARKGRAY));
		Blogin.setTypeface(Typeface.DEFAULT_BOLD);
		Blogin.setBackgroundColor(Color.WHITE);
        Blogin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                
                //Button 1
                Blogin.setTextColor(Color.parseColor(DARKGRAY));
                Blogin.setBackgroundColor(Color.WHITE);
                Llogin.setVisibility(View.VISIBLE);
                
                //Button2
                Bsellers.setTextColor(Color.WHITE);
                Bsellers.setBackgroundColor(Color.TRANSPARENT);
                Lsellers.setVisibility(View.GONE);
                
            }
        });
        
        Llogin = new LinearLayout(this);
        Llogin.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        Llogin.setPadding(8,8,8,8);
        Llogin.setGravity(Gravity.CENTER);
        Llogin.setOrientation(LinearLayout.VERTICAL);
        
        LayoutParams editTextParams = new LayoutParams(-1, 25);
        editTextParams.setMargins(0,0,0,8);
        
        EditText Username = new EditText(this);
        Username.setLayoutParams(editTextParams);
        Username.setPadding(5,0,5,0);
        Username.setHint("Insira seu usuario");
        Username.setTextSize(8f);
        Username.setHintTextColor(Color.parseColor(DARKGRAY));
        Username.setTextColor(Color.WHITE);
        Username.setAlpha(0.6f);
        android.graphics.drawable.GradientDrawable ICICJDI = new android.graphics.drawable.GradientDrawable();
        ICICJDI.setColor(Color.parseColor(LIGHTGRAY));
        ICICJDI.setCornerRadius(6);
        Username.setBackground(ICICJDI);
        if(Build.VERSION.SDK_INT >= 21) { Username.setElevation(10f); }
        
        EditText Password = new EditText(this);
        Password.setLayoutParams(editTextParams);
        Password.setPadding(5,0,5,0);
        Password.setHint("Insira sua senha");
        Password.setTextSize(8f);
        Password.setHintTextColor(Color.parseColor(DARKGRAY));
        Password.setTextColor(Color.WHITE);
        Password.setAlpha(0.6f);
        Password.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
        android.graphics.drawable.GradientDrawable EBDFBFE = new android.graphics.drawable.GradientDrawable();
        EBDFBFE.setColor(Color.parseColor(LIGHTGRAY));
        EBDFBFE.setCornerRadius(6);
        Password.setBackground(EBDFBFE);
        if(Build.VERSION.SDK_INT >= 21) { Password.setElevation(10f); }
        
        Button enter = new Button(this);
        enter.setLayoutParams(new LinearLayout.LayoutParams(-1, 30));
        enter.setPadding(2,2,2,2);
        enter.setText("Enter");
        enter.setTextSize(8f);
        enter.setAllCaps(false);
        enter.setTextColor(Color.WHITE);
        enter.setAlpha(0.8f);
        android.graphics.drawable.GradientDrawable HICIHEF = new android.graphics.drawable.GradientDrawable();
        HICIHEF.setColor(Color.parseColor(LIGHTGRAY));
        HICIHEF.setCornerRadius(6);
        enter.setBackground(HICIHEF);
        if(Build.VERSION.SDK_INT >= 21) { enter.setElevation(10f); }
        
        
        Bsellers = new Button(this);
        Bsellers.setLayoutParams(new LinearLayout.LayoutParams(-1, 20));
        Bsellers.setPadding(0,0,0,0);
        Bsellers.setAlpha(0.6f);
        Bsellers.setText("Sellers");
        Bsellers.setAllCaps(false);
        Bsellers.setTextSize(9.0f);
        Bsellers.setTextColor(Color.WHITE);
        Bsellers.setTypeface(Typeface.DEFAULT_BOLD);
		Bsellers.setBackgroundColor(Color.TRANSPARENT);
        Bsellers.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view){

                    //Button 1
                    Blogin.setTextColor(Color.WHITE);
                    Blogin.setBackgroundColor(Color.TRANSPARENT);
                    Llogin.setVisibility(View.GONE);
                    
                    //Button2
                    Bsellers.setTextColor(Color.parseColor(DARKGRAY));
                    Bsellers.setBackgroundColor(Color.WHITE);
                    Lsellers.setVisibility(View.VISIBLE);

                }
            });
            
        Lsellers = new LinearLayout(this);
        Lsellers.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        Lsellers.setPadding(8,8,8,8);
        Lsellers.setGravity(Gravity.CENTER_HORIZONTAL);
        Lsellers.setOrientation(LinearLayout.VERTICAL);
        
        
		setContentView(linear);
		linear.addView(linear2);
		linear2.addView(linear3);
		linear3.addView(TeamName);
		linear2.addView(linear4);
		linear4.addView(linear5);
		linear5.addView(Blogin);
        linear4.addView(Llogin);
        linear5.addView(Bsellers);
        linear4.addView(Lsellers);
        Llogin.addView(Username);
        Llogin.addView(Password);
        Llogin.addView(enter);
        
        addSellers("LKZINXS Z1", "http://wa.me/+5597999999999", "Whatsapp");
        addSellers("SellerName", "http://wa.me/+5597999999999", "Whatsapp");
        
	}
    
    private void addSellers(String nameSeller, String urlContact, String contactSeller){
        
        
        //// Contem Erros
        
        sellerContact = urlContact;
        
        LinearLayout linearSeller = new LinearLayout(this);
        linearSeller.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        linearSeller.setOrientation(LinearLayout.HORIZONTAL);
        
        TextView seller = new TextView(this);
        seller.setText(nameSeller + " - " + contactSeller);
        seller.setTextSize(8f);
        seller.setTextColor(Color.WHITE);
        seller.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view){

                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(sellerContact));
                    startActivity(i);

                }
            });
            
            
         
         Lsellers.addView(linearSeller);
         linearSeller.addView(seller);
        
    }
	
} 
